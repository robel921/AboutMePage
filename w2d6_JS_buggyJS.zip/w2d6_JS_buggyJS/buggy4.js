function somethingElse() {
    if (5 > 2) {
        alert("Bigger");
        if (5 < 2) {
            alert("Smaller");
        }
    }
}

function gogogo(){
    alert("Yay, it works!");

}